#!/bin/sh
docker run -it --rm chiapos:dev /app/RunTests


// PUBLIC IMPORT HEADER
#ifndef _UINT128_H_
#define _UINT128_H_
#include "uint128_t_config.include"
#define UINT128_T_EXTERN _UINT128_T_IMPORT
#include "uint128_t.include"
#endif


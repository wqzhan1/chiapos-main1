#!/bin/sh
docker build -t chiapos:dev .

